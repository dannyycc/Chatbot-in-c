void greeting();
void take_input(char * input);
void respond_to(char * input, char * response);
void goodbye();
